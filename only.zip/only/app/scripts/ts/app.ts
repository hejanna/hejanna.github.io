export function HelloTs() : void {
    console.log('Hello Ts!');
}

export function return1() : number {
    return 1;
}