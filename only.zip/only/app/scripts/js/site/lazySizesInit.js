(function lazySizesInit() {
	window.lazySizesConfig = window.lazySizesConfig || {};
	lazySizesConfig.loadMode = 1;
})();
