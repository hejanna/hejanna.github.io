function toggleActive(selector) {
	document.querySelector(selector).classList.toggle("isActive");
}
