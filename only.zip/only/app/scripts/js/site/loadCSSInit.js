(function loadCSSInit() {
	loadCSS("app/css/main.css");
})();
