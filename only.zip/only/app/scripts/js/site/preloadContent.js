(function preloadContent() {
	document.querySelector("body").classList.add("loaded");
})();
