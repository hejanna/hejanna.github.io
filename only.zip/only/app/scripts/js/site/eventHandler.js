// Setup all handler classes – these are used exclusively on elements that should be interactive via JS event handling
const THING_HANDLER = "js-object";

function eventHandler(e) {
	let clicked = e.target;

	//if (clicked.classList.contains(THING_HANDLER)) {
	//	thingHandler(e);
	//}
}
