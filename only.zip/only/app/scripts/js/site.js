// Specify project namespace
let ns = ns || {};

window.addEventListener("DOMContentLoaded", function() {
	document.addEventListener("click", function(e) {
		eventHandler(e);
	}, true);
});
