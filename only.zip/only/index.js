"use strict";

export default class App {
  welcomeMessage() {
    let message = "Welcome to ES6";
    return message;
  }
}